import '../styles/About.css'; 
import portper from "../assets/portper.png"; 
import arrow from "../assets/arrow.png"; 
const About = () => { 
  return ( 
    <div className="container"> 
      <div className="about-left"> 
        <h4 className="welcome">Welcome</h4> 
        <h1> 
          I have <span className="green">Creative Design</span> Experience 
        </h1> 
        <p> 
          I'm Tanvik, a creative Product Designer. I've been helping businesses 
          to solve their problems with my design for 2 years. 
        </p> 
        <div className="buttons"> 
          <button className="btngn">Contact Me</button> 
          <button className="btnview"> 
            View Portfolio <img className="arrow" src={arrow} alt="arrow" /> 
          </button> 
        </div> 
      </div> 
 
      <div className="about-right"> 
        <div className="image-box"> 
          <div className="green-box"></div> 
          <img src={portper} alt="Profile" className="profile-img" /> 
          <div className="outline-box"></div> 
        </div> 
      </div> 
    </div> 
  ); 
}; 
export default About;