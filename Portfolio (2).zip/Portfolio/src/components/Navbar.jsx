import React from 'react';
import '../styles/Navbar.css';
import logo from '../assets/port.png';

const Navbar = (props) => {
  const handlebtn = () => {
    props.enableMode();
  };
  
  return (
    <nav className={`navbar ${props.mode}`}>
      <div className="nav-container">

        <div className="nav-logo">
          <img src={logo} alt="logo" />
        </div>

        <ul className="nav-links">
          <li><a href="#">About</a></li>
          <li><a href="#">Skills</a></li>
          <li><a href="#">Portfolio</a></li>
          <li><a href="#">Testimonial</a></li>
        </ul>

        <div className="nav-right">
          <a href="#" className="cv-btn">Download CV</a>
        </div>

        {/*Toggle */}
        <div className="mode-toggle">
          <div className="toggle-container" onClick={handlebtn}>
            <div className={`toggle-span ${props.mode === 'dark' ? 'dark' : 'light'}`}>
              <span>{props.mode === 'dark' ? 'dark' : 'light'}</span>
            </div>
          </div>
        </div>

      </div>
    </nav>
  );
};

export default Navbar;

