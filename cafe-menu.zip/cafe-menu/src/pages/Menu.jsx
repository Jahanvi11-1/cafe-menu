import { useState, useEffect } from 'react'
import axios from 'axios'
import './Menu.css'

export default function Menu() {
  const [meals, setMeals] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    async function fetchMeals() {
      try {
        const res = await axios.get(
          'https://www.themealdb.com/api/json/v1/1/filter.php?c=Seafood'
        )
        setMeals(res.data.meals)
      } catch (err) {
        setError('Failed to load menu')
      } finally {
        setLoading(false)
      }
    }
    fetchMeals()
  }, [])

  if (loading) return <p>Loading menu...</p>
  if (error) return <p>{error}</p>

  return (
    <section className="menu-page">
      <h1>Our Special Menu</h1>
      <div className="menu-grid">
        {meals.map(meal => (
          <div key={meal.idMeal} className="menu-card">
            <img src={meal.strMealThumb} alt={meal.strMeal} />
            <h3>{meal.strMeal}</h3>
          </div>
        ))}
      </div>
    </section>
  )
}
