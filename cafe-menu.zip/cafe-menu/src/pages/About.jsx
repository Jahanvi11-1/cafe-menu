export default function About() {
  return (
    <section>
      <h1>About Us</h1>
      <p>Family-owned café serving love and coffee since 2010.</p>
    </section>
  )
}
