import "../styles/Review.css";

const reviews = [
  {
    name: "Amir Uddin",
    role: "UX Designer",
    text: "We will also facilitate the business marketing of these products with our SEO experts so that they become a ready to use website & help sell product from company",
    stars: 5
  },
  {
    name: "Salim Ahmed",
    role: "UI Designer",
    text: "We will also facilitate the business marketing of these products with our SEO experts so that they become a ready to use website & help sell product from company",
    stars: 5
  },
  {
    name: "Guy Hawkins",
    role: "UX Designer",
    text: "We will also facilitate the business marketing of these products with our SEO experts so that they become a ready to use website & help sell product from company",
    stars: 5
  }
];

const Review = () => {
  return (
    <section className="review-section">
      <h4 className="review-subtitle">Reviews</h4>
      <h1 className="review-title">
        Our Customer Say Something <span>About Us</span>
      </h1>

      <div className="review-container">
        {reviews.map((rev, idx) => (
          <div key={idx} className="review-card">
            <div className="review-stars">
              {"★".repeat(rev.stars)}
            </div>
            <p className="review-text">{rev.text}</p>
            <h4 className="review-name">{rev.name}</h4>
            <p className="review-role">{rev.role}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Review;
