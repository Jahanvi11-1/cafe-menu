import "../styles/Skill.css";
import diamond from "../assets/daimond.png";
import wave from "../assets/htr.png";
import edu from "../assets/edu.png";

const Skill = () => {
    return (
        <>
        <div className="skill-container">
            <div className="skill">
                <div className="skill-left">
                    <h4 className="skill-h4">My Skills</h4>
                    <h1 className="heading">
                        Why Hire Me For Your Next <span>Project?</span>
                    </h1>
                    <p className="text">
                        I'm Specialist in UI/UX Designer. My passion is designing & solving 
                        problems through user experience and research.
                    </p>
                    <button className="btnHire">Hire Me</button>
                </div>

                <div className="skill-right">
                    <div className="diamond">
                        <img src={diamond} alt="diamond" className="diamond-img"/>
                        <h4 className="diamond-h4">Visual Design</h4>
                        <p className="diamond-p">
                            Create user interface design with unique & modern ideas.
                        </p>
                    </div>

                    <div className="wave">
                        <img src={wave} alt="wave" className="wave-img"/>
                        <h4 className="wave-h4">Design Prototype</h4>
                        <p className="wave-p">
                            Create advance design prototype with Figma apps.
                        </p>
                    </div>

                    <div className="edu">
                        <img src={edu} alt="edu" className="edu-img"/>
                        <h4 className="edu-h4">UX Research</h4>
                        <p className="edu-p">
                            Create digital user products with updated ideas.
                        </p>
                    </div>
                </div>
            </div>
        </div>
        </>
    );
};

export default Skill;
