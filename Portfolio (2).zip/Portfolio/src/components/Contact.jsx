import "../styles/Contact.css";

const Contact = () => {
  return (
    <section className="contact-section">
      <h4 className="contact-subtitle">Contact</h4>
      <h1 className="contact-title">Let's Discuss Your <span>Project</span></h1>
      <p className="contact-text">Let's make something new, different and more meaningful or make things more visual or conceptual</p>

      <div className="contact-container">
        <div className="contact-info">
          <div className="contact-box">
            <h4>Call me</h4>
            <p>+8801613986687</p>
          </div>
          <div className="contact-box">
            <h4>Email me</h4>
            <p>ahmedtanvir9687@gmail.com</p>
          </div>
          <div className="contact-box">
            <h4>Address</h4>
            <p>Zakirgonj, Sylhet, Bangladesh</p>
          </div>
        </div>

        <form className="contact-form">
          <input type="text" placeholder="Full name" />
          <input type="email" placeholder="Your email" />
          <input type="text" placeholder="Phone number" />
          <input type="text" placeholder="Budget" />
          <textarea placeholder="Message"></textarea>
          <button type="submit" className="btnSubmit">Submit Message</button>
        </form>
      </div>
    </section>
  );
};

export default Contact;
