import '../styles/Portfolio.css';
import zomato from '../assets/zomato.png';
import rapido from '../assets/rapido.png';
import flipkart from '../assets/flipkart.png';

const Portfolio = () => {
    return (
        <div className="portfolio-container">
            <div className="portfolio">
                <div className="portfolio-left">
                    <h4 className="portfolio-h4">Portfolio</h4>
                    <h1>
                        My Creative Works Latest <span className="green">Projects</span> Experience
                    </h1>
                    <p>
                        I have selected and mentioned here some of my latest projects to share with you.
                    </p>
                    <div className="buttons">
                        <button className="btngn">Show More</button>
                    </div>
                </div>

                <div className="portfolio-right">
                    <div className="image-box1">
                        <img src={zomato} alt="zomata" className="zomato" />
                        <img src={rapido} alt="rapido" className="rapido" />
                        <img src={flipkart} alt="flipkart" className="flipkart" />
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Portfolio;