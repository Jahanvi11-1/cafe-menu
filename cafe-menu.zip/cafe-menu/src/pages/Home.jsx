export default function Home() {
  return (
    <section className="hero">
      <h1>Welcome to CozyCafe</h1>
      <p>Where every sip feels like a warm hug.</p>
    </section>
  )
}
