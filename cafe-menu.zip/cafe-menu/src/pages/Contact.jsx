export default function Contact() {
  return (
    <section>
      <h1>Contact Us</h1>
      <p>Email: hello@cozycafe.com | Phone: +91 98765 43210</p>
    </section>
  )
}
