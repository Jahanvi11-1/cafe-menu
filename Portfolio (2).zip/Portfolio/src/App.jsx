import React, { useState } from 'react';

import Navbar from "./components/Navbar";
import About from "./components/About";
import Work from "./components/Work";
import Skill from "./components/Skill";
import Portfolio from "./components/Portfolio";
import Contact from "./components/Contact";

import './App.css';

const App = () => {
  const [mode, setmode] = useState('light');

  //for body section
  const enableMode = () => {
    if (mode === 'light') {
      setmode('dark');
      document.body.style.backgroundColor = 'black';
      document.body.style.Color = 'white';

    } else {
      setmode('light');
      document.body.style.backgroundColor = 'white';
      document.body.style.Color = 'black';

    }
  };

  return (
    <>
      <Navbar mode={mode} enableMode={enableMode} />
      <div className={`app-container ${mode}`}>
        <About />
        <Work />
        <Skill />
        <Portfolio />
        <Contact />
      </div>
    </>
  )
}

export default App;