import './Footer.css'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-col">
        <h3>CozyCafe</h3>
        <p>Your daily dose of happiness in a cup!</p>
      </div>
      <div className="footer-col">
        <h4>Quick Links</h4>
        <ul>
          <li>Home</li>
          <li>Menu</li>
          <li>About</li>
          <li>Contact</li>
        </ul>
      </div>
      <div className="footer-col">
        <h4>Follow Us</h4>
        <p>Instagram | Facebook | Twitter</p>
      </div>
    </footer>
  )
}
