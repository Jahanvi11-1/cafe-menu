import "../styles/Work.css";

const Work = () =>{
    return(
        <>
            <div className="work-container">
                <div className="work">
                    <h3>80+</h3>
                    <p>Satisfied clients</p>
                </div>
                <div className="divider"></div>
                <div className="work">
                    <h3>200+</h3>
                    <p>Projects completed</p>
                </div>
                <div className="divider"></div>
                <div className="work">
                    <h3>99+</h3>
                    <p>Reviews given</p>
                </div>
            </div>
        </>
    )
}

export default Work;