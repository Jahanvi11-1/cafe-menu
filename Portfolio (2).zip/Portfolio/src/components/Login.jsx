import React, { useState } from 'react';
import "../styles/Login.css";

const Login = () => {
    const [username, setUsername] = useState("");
    const [password, setPw] = useState("");

    const handleform = (e) => {
        e.preventDefault();
        const Data = {
            username,            //name from the form 
            password,
        }
        console.log(Data);

    }
    return (
        <>
            <form onSubmit={handleform}>
                <h2>Login Form</h2>
                <label htmlFor="username">Username:</label>
                <input type="text" name="username" value={[username]}/*current value from state*/ onChange={(e) => setUsername(e.target.value)} />
                <br />
                <label htmlFor="password">Password:</label>
                <input type="password" name="password" value={[password]}/*current value from state*/ onChange={(e) => setPw(e.target.value)} />
                <br />
                <button type="submit">Sumbit</button>
            </form>
        </>
    )
};

export default Login;
